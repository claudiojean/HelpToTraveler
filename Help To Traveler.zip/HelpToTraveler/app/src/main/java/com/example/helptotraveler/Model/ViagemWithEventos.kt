package com.example.helptotraveler.Model

import androidx.room.Embedded
import androidx.room.Relation

class ViagemWithEventos(
    @Embedded val viagem: Viagem,
    @Relation(
        parentColumn = "viagemId",
        entityColumn = "fkviagemId"
    )
    val eventos: List<Evento>
)
