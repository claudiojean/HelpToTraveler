package com.example.helptotraveler


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.activity.viewModels
import com.example.helptotraveler.Model.Viagem
import com.example.helptotraveler.db.HttApplication
import com.example.helptotraveler.db.HttViewModel
import com.example.helptotraveler.db.HttViewModelFactory
import kotlinx.android.synthetic.main.activity_add_travel.*
import java.text.SimpleDateFormat
import java.util.*

class AddTravel : AppCompatActivity() {

    lateinit var datepickerB:DatePicker
    lateinit var datepickerF:DatePicker

    private val viewModel: HttViewModel by viewModels {
        HttViewModelFactory((application as HttApplication).repository)
    }

    lateinit var optionTravel:Spinner
    lateinit var optionTransport:Spinner
    lateinit var optionCoin:Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_travel)

        optionTravel = findViewById(R.id.spTravelType)
        optionTransport = findViewById(R.id.spTransport)
        optionCoin = findViewById(R.id.spCoin)

        val optionsTravel = arrayOf("Nacional","Internacional")
        val optionsTransport = arrayOf("Carro","Avião","Ônibus")
        val optionsCoin = arrayOf("Dólar","Euro")

        optionTravel.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,optionsTravel)
        optionTransport.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,optionsTransport)
        optionCoin.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,optionsCoin)

        btnSave.setOnClickListener {
            insertToDataBase()
        }
    }

    private fun insertToDataBase(){

        datepickerB = findViewById(R.id.dpBeginDay)
        datepickerF = findViewById(R.id.dpFinalDay)

        val dayB = datepickerB.dayOfMonth
        val monthB = datepickerB.month
        val yearB = datepickerB.year

        val dayF = datepickerF.dayOfMonth
        val monthF = datepickerF.month
        val yearF = datepickerF.year

        val calendarB = Calendar.getInstance()
        calendarB.set(yearB, monthB, dayB)

        val calendarF = Calendar.getInstance()
        calendarF.set(yearF, monthF, dayF)

        val sdf = SimpleDateFormat("dd-MM-yyyy")

        val origem : String = etOrigin.text.toString()
        val destino : String = etDestiny.text.toString()
        val tipoViagem : String = optionTravel.selectedItem.toString()
        val transporte : String = optionTransport.selectedItem.toString()
        val moeda : String = optionCoin.selectedItem.toString()
        val dataI : String = sdf.format(calendarB.time)
        val dataF : String = sdf.format(calendarF.time)
        val viagem = Viagem(0,origem,destino,tipoViagem,transporte,moeda,dataI,dataF)
        viagem.calcularMoedaExterna(this)
        viewModel.insertViagem(viagem)
    }

}