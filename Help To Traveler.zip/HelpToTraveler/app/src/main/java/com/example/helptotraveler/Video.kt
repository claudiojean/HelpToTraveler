package com.example.helptotraveler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.MediaController
import kotlinx.android.synthetic.main.activity_video.*

class Video : AppCompatActivity() {
    private var mediaController: MediaController? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        startVideo()
    }
    private fun startVideo(){
        videoView.setVideoPath("https://r2---sn-bg0ezn7y.googlevideo.com/videoplayback?expire=1623741173&ei=lf7HYLK4A9fBgQeru474Bg&ip=83.136.179.136&id=o-APx0SX7qrW9e80sg1L9_EpBZqAys8DKF-elHUPyPRQdN&itag=18&source=youtube&requiressl=yes&vprv=1&mime=video%2Fmp4&ns=os0lU73iWxiyL0cE7l8-tVoF&gir=yes&clen=170656&ratebypass=yes&dur=3.691&lmt=1576691039201302&fexp=24001373,24007246&c=WEB&txp=1311222&n=6CFRZ6A_cMvxnvDGrF7&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Cgir%2Cclen%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAJ4ljAwmm-rX1oa35AdcLcW__J4WhLy1I6iJP0UiyXOyAiEAm3aE1VcedzcJ_ePdtwO65w_QZKjXlsNEy8L7X55hUsI%3D&rm=sn-nxg8pivnupob-cjoe7l,sn-nxg8pivnupob-h5q67l,sn-h5q6z7l&req_id=a042fbef9470a3ee&ipbypass=yes&redirect_counter=4&cm2rm=sn-bg0ds7l&cms_redirect=yes&mh=nn&mip=143.208.72.9&mm=34&mn=sn-bg0ezn7y&ms=ltu&mt=1623720754&mv=m&mvi=2&pl=23&lsparams=ipbypass,mh,mip,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRAIgHFYJbJOMnKyk9itiELIjtkNqd7w4kTqwjKEqWhXwPCICIEPbWfNySF_B-kjhiIQrQjRfOM2douP8JHr1puC78rK3")
        mediaController = MediaController(this)
        mediaController?.setAnchorView(videoView)
        videoView.setMediaController(mediaController)
        videoView.start()
    }
}