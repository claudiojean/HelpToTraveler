package com.example.helptotraveler.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.helptotraveler.Model.Evento
import com.example.helptotraveler.Model.Viagem
import kotlinx.coroutines.CoroutineScope

@Database(entities = [Viagem::class,Evento::class], version = 4)
abstract class HelpToTravelerDataBase :RoomDatabase() {
    abstract fun viagemDao(): viagemDao
    abstract fun eventoDao(): eventoDao
    companion object {
        @Volatile
        private var INSTANCE: HelpToTravelerDataBase? = null
        fun getDatabase(
            context: Context,
            scope: CoroutineScope
        ): HelpToTravelerDataBase{
            return INSTANCE?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HelpToTravelerDataBase::class.java,
                    "helptotraveler_database"
                )
                    .fallbackToDestructiveMigration()
                    //.addCallback(HelpToTravelerCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /*private class HelpToTravelerCallback(
            private val scope: CoroutineScope
        ): RoomDatabase.Callback(){
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let{ database ->
                    scope.launch(Dispatchers.IO){
                        populateDatabase(database.viagemDao())
                    }
                }
            }
        }*/

        /*suspend fun populateDatabase(viagemDao: ViagemDao) {
            // Start the app with a clean database every time.
            // Not needed if you only populate on creation.
            viagemDao.deleteAll()

            var viagem = Viagem()
            viagemDao.insert(viagem)
            viagem = Viagem()
            viagemDao.insert(viagem)
        }*/

    }

}